//VERSION: 9/27/2022
/*
TYPEDEFS and MEMBER CONSTANTS for the transaction_log class:
    typedef ____ value_type
        transaction::value_type is the data type of the items in the transaction_log. It can be any object type
        that supports .value() and .id(), and more

    typedef value_type::value_type transaction_value_type;
        A convenience typedef that corresponds to the actual type of the number inside a transaction

    typedef double add_type;
        The type of value you expect to add into the transaction log, assuming it has less range than a transaction.
        However, easier to use than creating a transaction each time.

    typedef ____ size_type
        sequence::size_type is the data type of any variable that keeps track of how many items are in a sequence.

    static const size_type GROW_FACTOR = 2; //
        The initial state of a log will be zero capacity. On first insert or append, the size will be 1. However, each additional
        capacity increase will grow by GROW_FACTOR.

 CONSTRUCTOR for the sequence class:
    transaction_log()
        Default constructor, does NOT initialize anything on the heap
        Precondition: N/A
        Postcondition: Initialized object

    transaction_log(const transaction_log&)
        A memory safe copy constructor
        Precondition: N/A
        Postcondition: A copy of the passed log is created

 Destructor
    virtual ~transaction_log();
        Precondition: N/A
        Postcondition: All heap storage is reclaimed

 MODIFICATION MEMBER FUNCTIONS for the transaction_log class:
    void reserve(size_type new_capacity)
        Precondition: N/A
        Postcondition: The transaction_log's capacity is changed to the new_capacity
            (but not less that the number of items already in the log).
            The insert/append functions will work efficiently (without allocating new memory) until this new capacity
            is reached.

    transaction_log& operator=(const transaction_log &)
        A memory safe copy constructor
        Precondition: N/A
        Postcondition: A copy of the passed log is returned

   void reset()
     Precondition: At least one transaction in the log
     Postcondition: The first transaction log becomes the current item

    void prev( )
        Precondition: At least one transaction in the log and current is valid
        Postcondition: The new current item is the item immediately before the original current item.
            If already the first item, current becomes invalid

    void next( )
        Precondition: At least one transaction in the log and current is valid
        Postcondition: The new current item is the item immediately after the original current item.
            If already the last item, current becomes invalid

    void set_current_by_id(size_type target_id)
        Precondition: N/A
        Postcondition: Set current to whatever transaction has the target_id. In the event that target_id is not found,
            current will be invalid

    void insert(const transaction_value_type&)
        Postcondition: A new copy of entry has been inserted in the log
            before the current item. If there was no current item, then the new entry
            has been inserted at the front of the log. In either case, the newly
            inserted item is now the current item of the log.

    void append(const transaction_value_type&)
        Postcondition: A new copy of entry has been inserted in the log after
            the current item. If there was no current item, then the new entry has
            been appended to the end of the log. In either case, the newly
            inserted item is now the current item of the log.

     void insert(const add_type&);
        Precondition: N/A
        Postcondition: Converts item to value_type and inserts based on the rules given in previous insert

    void append(const add_type&);
        Precondition: N/A
        Postcondition: Converts item to value_type and appends based on the rules given in previous insert

    transaction_log& operator+=(const transaction_log& logIn);
        Precondition: N/A
        Postcondition: Appends the logIn transactions (from logIns current to end) into object after the current item.
            Current is not changed.
            If current item is invalid, the transaction get added to the end.
            If logIns current is invalid, the entire log is copied.
            Note: It is okay if the transaction ids are not preserved from logIn (however, would be cool if they were).

 CONSTANT MEMBER FUNCTIONS for the sequence class:
    size_type size( ) const
        Precondition: N/A
        Postcondition: The return value is the number of transactions in the log.

    bool has_prev() const;
        Precondition: N/A
        Postcondition: Returns true if their exists a transaction before the current, false otherwise

    bool has_next() const;
        Precondition: N/A
        Postcondition: Returns true if their exists a transaction after the current, false otherwise

    const value_type& current() const { return log[current_index]; }
        Precondition: Current is valid
        Postcondition: Returns a reference to the current transaction

    bool current_is_valid() const;
        Precondition: N/A
        Postcondition: Returns true if there is a current transaction, false otherwise.

    bool operator==(const transaction_log &) const;
        Precondition: N/A
        Postcondition: Returns true if the order of two transactions are equivalent. Note, transaction ids are ignored,
            only the transaction values matter. Only transactions from current to the end are inspected. Returns
            false otherwise.

    bool operator!=(const transaction_log &) const;
        Precondition: N/A
        Postcondition: The opposite of ==

    const value_type* transactions() const { return log; }
        Precondition: N/A
        Postcondition: Returns a constant pointer to the transaction log.

        transaction_value_type sum() const;
        Precondition: current is valid
        Postcondition: The return sum of the values in the transaction log from current to end of the log.

    const value_type& max() const;
        Precondition: current is valid
        Postcondition: Returns a reference to the maximum transaction in the transaction log from current to end of the log.
            This is based on the transaction value and not the transaction id.

 VALUE SEMANTICS for the sequence class:
    Assignments and the copy constructor may be used with transaction_log objects.

 DYNAMIC MEMORY USAGE by the List
   If there is insufficient dynamic memory, then the following functions
   throw a BAD_ALLOC exception: The constructors, insert, append.

 Invariant declaration    EXPECT_FALSE(threeItems.has_next());
  The class will maintain the physical capacity of the array and the number of items
      the object has stored in the physical array.
      ...
******************
      TODO: STUDENT add to invariant how the is_item is handled related to next, prev, and so on.
          COPY this ENTIRE invariant declaration to the top of your transaction_log.cpp
******************

*/

#ifndef PROJ_TRANSACTIONS_DYN_TRANSACTION_LOG_H
#define PROJ_TRANSACTIONS_DYN_TRANSACTION_LOG_H

#include <string>
#include <cmath>
#include <sstream>
#include "transaction.h"

namespace DS {
    class transaction_log {
    public:
        typedef transaction value_type;
        typedef value_type::value_type transaction_value_type;
        typedef double add_type;
        typedef size_t size_type;
        static const size_type GROW_FACTOR = 2; //When resizing, multiply capacity by this amount

        //Constructors
        transaction_log() : capacity(0), used(0), current_index(0), log(nullptr) {}
        transaction_log(const transaction_log&);

        //Destructor
        virtual ~transaction_log();

        //Mutators
        transaction_log& operator=(const transaction_log &);
        void reserve(size_type new_capacity);
        void insert(const add_type&);
        void append(const add_type&);
        void insert(const transaction_value_type&);
        void append(const transaction_value_type&);
        transaction_log& operator+=(const transaction_log &);

        //Move the cursor
        void reset() { current_index = 0; }
        void prev();
        void set_current_by_id(size_type target_id);
        void next();

        //Accessors
        bool has_prev() const;
        bool has_next() const;
        bool current_is_valid() const;
        const value_type& current() const { return log[current_index]; }
        bool operator==(const transaction_log &) const;
        bool operator!=(const transaction_log &) const;
        const value_type* transactions() const { return log; }
        size_type size() const {return used; }
        transaction_value_type sum() const;
        const value_type& max() const;
        bool shared(const transaction_log & r) const { return (capacity > 0 && log == r.log ); }

        //BELOW IS FOR TESTING BY GRADER ONLY, DO NOT USE THESE MEMBER FUNCTIONS IN YOUR CODE
        transaction_log(std::initializer_list<add_type> l) {
            if ( l.size() == 0 ) {
                used = current_index = capacity = 0;
                log = nullptr;
            } else {
                capacity = uipow(2,static_cast<size_type>(ceil(log2(static_cast<double>(l.size())))));
                log = new value_type[capacity];
                size_t i = 0;
                for (auto p = l.begin(); p != l.end(); ++p, ++i)
                    log[i] = transaction(*p);
                current_index = 0;
                used = l.size();
            }
        }
        explicit operator std::string() const {
            std::ostringstream oss;
            oss << '[';
            if ( used > 0 ) {
                oss << log[0].value();
                for ( size_type i = 1 ; i < used ; ++i )
                    oss << ", " << log[i].value();
            }
            oss << ']';
            return oss.str();
        }
        size_type _rawCapacity() const { return capacity; }
        size_type _rawUsed() const { return used; }
        const value_type* _rawLog() const { return log; }
        size_type _rawCurrent() const { return current_index; }
        size_type& _rawCapacity() { return capacity; }
        size_type& _rawUsed() { return used; }
        value_type*& _rawLog() { return log; }
        size_type& _rawCurrent() { return current_index; }
        //ABOVE IS FOR TESTING BY GRADER ONLY, DO NOT USE THESE MEMBER FUNCTIONS IN YOUR CODE

    private:
        size_type capacity; //Current size of the allocated array
        size_type used; //Number of transactions in the array
        size_type current_index; //Cursor
        value_type * log; //The actual transaction log array
    };
}

#endif //PROJ_TRANSACTIONS_DYN_TRANSACTION_LOG_H
