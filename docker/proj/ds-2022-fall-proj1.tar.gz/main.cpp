//VERSION: 9/27/2022
#include <iostream>

#include "transaction_log.h"
#include "helpers.h"

using namespace DS;
int main() {

    transaction_log log;
    std::cout << "Transactions:" << std::endl << log << std::endl;
    log.append(34);
    log.append(35);

    log.append(-36);
    log.append(37);
    log.append(38);
    log.append(39);
    log.append(40);
    log.prev();
    log.prev();
    log.prev();
    log.append(41.41);
    log.append(42);
    log.append(-43);
    log.append(44);
    //log.start();
    log.reset();
    std::cout << transaction_id_list(log) << std::endl;
    std::cout << "Transactions:" << std::endl << log << std::endl;
    std::cout << "SUM:" << log.sum() << std::endl;
    return 0;
}

