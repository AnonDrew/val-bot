//VERSION: 9/27/2022
#ifndef PROJ_TRANSACTIONS_DYN_LONG_DECIMAL_H
#define PROJ_TRANSACTIONS_DYN_LONG_DECIMAL_H

#include <cstdint>
#include <string>

namespace DS {

    class long_decimal {
    public:
        typedef uint_least64_t value_type;
        static const unsigned short DEFAULT_PRECISION = 2;

        long_decimal() :
                decimal_point_count(DEFAULT_PRECISION), negative(false), whole_units(0), fractional_units(0) {}

        explicit long_decimal(unsigned short precision) :
                decimal_point_count(precision), negative(false), whole_units(0), fractional_units(0) {}

        explicit long_decimal(double data, unsigned short precision = DEFAULT_PRECISION);

        long_decimal(bool negative, value_type whole, value_type fractional,
                     unsigned short precision = DEFAULT_PRECISION) :
                decimal_point_count(precision), negative(negative), whole_units(whole), fractional_units(fractional) {}

        long_decimal(const long_decimal &data_in, unsigned short precision = DEFAULT_PRECISION) :
                decimal_point_count(precision),
                negative(data_in.negative), whole_units(data_in.whole_units),
                fractional_units(data_in.fractional_units) {}

        long_decimal& operator=(const long_decimal&); //added to remove warning

        bool operator==(const long_decimal &) const;

        bool operator!=(const long_decimal &right) const { return !(*this == right); }

        long_decimal operator+(const long_decimal &) const;

        long_decimal &operator+=(const long_decimal &);

        long_decimal operator-() const; //unary
        long_decimal operator-(const long_decimal &) const;

        bool is_negative() const { return negative; }

        unsigned short precision() const { return decimal_point_count; }

        value_type whole_value() const { return whole_units; }

        value_type fractional_value() const { return fractional_units; }

        std::string to_string() const;

        bool operator<(const long_decimal &rhs) const;

        bool operator>(const long_decimal &rhs) const;

        bool operator<=(const long_decimal &rhs) const;

        bool operator>=(const long_decimal &rhs) const;

    private:
        typedef int_least64_t s_value_type;
        unsigned short decimal_point_count;
        bool negative;
        value_type whole_units;
        value_type fractional_units;
    };

    std::ostream &operator<<(std::ostream &out, const long_decimal &);

    long_decimal::value_type uipow(long_decimal::value_type base, long_decimal::value_type exp);
}
#endif //PROJ_TRANSACTIONS_DYN_LONG_DECIMAL_H
