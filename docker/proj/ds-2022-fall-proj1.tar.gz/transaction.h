//VERSION: 9/27/2022
/*
TYPEDEFS and MEMBER CONSTANTS for the transaction_log class:
    typedef long_decimal value_type;
        data type of the objects numeric value

    static const unsigned short PRECISION = 2;
        number of digits after the decimal points that will be kept by value_type

    static size_t next_id;
        Since every transaction must have a unique id, this will store the id of the next transaction. This is static
        so that all objects can see this.

    static unsigned short id_digits;
        Number of digits needed to represent the largest tranaction id known. Allows the output to be more aligned.

CONSTRUCTOR for the sequence class:
    transaction() : transaction_id(0), transaction_value(value_type(PRECISION)) {  }
        Precondition: N/A
        Postcondition: Initialized object without a unique transaction id. This makes it easier to make copies
            of a transaction without getting a new id as a result.

    explicit transaction(double data_in)
        Precondition: N/A
        Postcondition: Creates a new object with a new unique transaction id. The passed double will loose any digits
            after the decimal point after the first PRECISION digits

    explicit transaction(const value_type &data_in)
        Postcondition: Creates a new object with a new unique transaction id.

MODIFICATION MEMBER FUNCTIONS for the transaction_log class:
    Not any

CONSTANT MEMBER FUNCTIONS for the sequence class:
    size_t id() const
        Precondition: N/A
        Postcondition: Returns the transaction id of the object

    const value_type& value() const
        Precondition: N/A
        Postcondition: Returns the numeric value of the object

    bool is_negative() const
        Precondition: N/A
        Postcondition: Returns true if the numeric value is negative, false otherwise

    bool operator==(const transaction&) const;
        Precondition: N/A
        Postcondition: Compares two transactions based on the numeric value only, transaction id is ignored. Returns
            true when the numeric values are the same, false otherwise.

    bool operator!=(const transaction& right) const
        Precondition: N/A
        Postcondition: Opposite of ==

    transaction operator+(const transaction&) const;
        Precondition: N/A
        Postcondition: Returns a new transaction object that has the result of both numberic values added together

    transaction operator-() const; //unary
        Precondition: N/A
        Postcondition: Returns a new transaction object that has the sign of the numeric value flipped

    transaction operator-(const transaction&) const;
        Precondition: N/A
        Postcondition: Returns a new transaction object that has the result of both numberic values subtracted together

    std::string to_string() const;
        Precondition: N/A
        Postcondition: Returns a string of the transaction with the id and amount, example:
            [##] + $##.##
            or
            [##] - $##.##
            Where the transaction id is within the square brackets. The sign of the value will always show.
            The number of digits after the decimal is dependant on PRECISION.

VALUE SEMANTICS for the sequence class:
    Assignments and the copy constructor may be used with transaction_log objects.

DYNAMIC MEMORY USAGE by the List
   No explicit usage of dynamic memory

Invariant declaration
  Once a transaction is created, it cannot be modified. Therefore, the invariant is 100% protected.

Non-Member functions

std::ostream& operator<<(std::ostream& out, const transaction&);
    Precondition: N/A
    Postcondition: Outputs to standard out a string of the transaction with the id and amount, example:
        [##] + $##.##
        or
        [##] - $##.##
        Where the transaction id is within the square brackets. The sign of the value will always show.
        The number of digits after the decimal is dependant on PRECISION.

*/


#ifndef PROJ_TRANSACTIONS_DYN_TRANSACTION_H
#define PROJ_TRANSACTIONS_DYN_TRANSACTION_H

#include <cstdint>  // provides uint_least64_t
#include <iostream>
#include <string>
#include "long_decimal.h"

namespace DS {
    class transaction {
    public:
        typedef long_decimal value_type;
        static const unsigned short PRECISION = 2;
        static size_t next_id;
        static unsigned short id_digits;
        transaction() : transaction_id(0), transaction_value(value_type(PRECISION)) {  }
        explicit transaction(double data_in) :transaction_id(next_id), transaction_value(data_in, PRECISION) {
            update_id_digits();
        }
        explicit transaction(const value_type &data_in) :
                transaction_id(next_id), transaction_value(data_in, PRECISION) {
            update_id_digits();
        }
        size_t id() const { return transaction_id; }
        const value_type& value() const { return transaction_value; }
        bool is_negative() const { return transaction_value.is_negative(); }
        bool operator==(const transaction&) const;
        bool operator!=(const transaction& right) const { return !(*this == right); }
        transaction operator+(const transaction&) const;
        transaction operator-() const; //unary
        transaction operator-(const transaction&) const;
        std::string to_string() const;
    private:
        void update_id_digits() const;      // Internal function, sounds the number of digits in the current id
        size_t transaction_id;              // Every transaction has a unique id
        value_type transaction_value;       // Holds the actual numeric value of this object
    };

    std::ostream& operator<<(std::ostream& out, const transaction&);


} // End of DS namespace

#endif //PROJ_TRANSACTIONS_DYN_TRANSACTION_H
