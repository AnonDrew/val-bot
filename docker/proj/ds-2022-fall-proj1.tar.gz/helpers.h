//VERSION: 9/27/2022
#ifndef PROJ_TRANSACTIONS_DYN_HELPERS_H
#define PROJ_TRANSACTIONS_DYN_HELPERS_H

#include <iostream>
#include <string>
#include "transaction_log.h"

namespace DS {
    std::ostream& operator<<(std::ostream &out, const transaction_log&);
    std::string transaction_id_list(const transaction_log&);
    std::string transaction_id_reversed_list(const transaction_log&);
}

#endif //PROJ_TRANSACTIONS_DYN_HELPERS_H
