//VERSION: 9/27/2022
//Added some exceptions
#include <sstream>
#include <stdexcept>
#include "helpers.h"

namespace DS {

    std::ostream &operator<<(std::ostream &out, const transaction_log& log) {
        //Make a copy of the head_ptr so that we can move the cursor
        transaction_log logIterator(log);
        if ( log.size() != logIterator.size() )
            throw std::runtime_error( "operator<< will not work until copy constructor, next(), and has_next() is implemented and working." );
        if ( log.shared(logIterator) )
            throw std::runtime_error( "operator<< will not work until you override the copy constructor." );
        if ( log.current_is_valid() ) {
            out << logIterator.current();
            while (logIterator.has_next()) {
                logIterator.next();
                out << std::endl << logIterator.current();
            }
        }
        return out;
    }

    std::string transaction_id_list(const transaction_log& log) {
        std::ostringstream oss;
        oss << '[';
        if ( log.size() > 0 ) {
            transaction_log logIterator(log);
            if ( log.size() != logIterator.size() )
                throw std::runtime_error( "transaction_id_list will not work until copy constructor, next(), and has_next() is implemented and working." );
            if ( log.shared(logIterator) )
                throw std::runtime_error( "transaction_id_list will not work until you override the copy constructor." );
            oss << logIterator.current().id();
            while ( logIterator.has_next() ) {
                logIterator.next();
                oss << ", " << logIterator.current().id();
            }
        }
        oss << ']';
        return oss.str();
    }

    std::string transaction_id_reversed_list(const transaction_log& log) {
        std::ostringstream oss;
        oss << '[';
        if ( log.size() > 0 ) {
            transaction_log logIterator(log);
            if ( log.size() != logIterator.size() )
                throw std::runtime_error( "transaction_id_reversed_list will not work until copy constructor, next(), and has_next() is implemented and working." );
            if ( log.shared(logIterator) )
                throw std::runtime_error( "transaction_id_reversed_list will not work until you override the copy constructor." );
            oss << logIterator.current().id();
            while ( logIterator.has_prev() ) {
                logIterator.prev();
                oss << ", " << logIterator.current().id();
            }
        }
        oss << ']';
        return oss.str();
    }

}
