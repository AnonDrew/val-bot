//VERSION: 9/27/2022
#include <sstream> //For ostringstream
#include <cmath> //For pow
#include <iomanip> //For setfill
#include <locale> //Not needed in CLion's C++11, keeping in case your IDE needs it
#include "long_decimal.h"

namespace DS {
    long_decimal::long_decimal(double value, unsigned short precision) :
            decimal_point_count(precision), negative(value < 0), whole_units(static_cast<value_type>(value < 0 ? -value : value)),
            fractional_units(
                    static_cast<value_type>((value < 0 ? -value : value) * pow(10, precision)) % uipow(10, precision))
    {
    }

    //Implemented trivial operator to suppress gcc deprecated warning
    //Of course, overriding trivial function causes CLion to complain. :)
    long_decimal &long_decimal::operator=(const long_decimal &rhs) { // NOLINT(modernize-use-equals-default)
        decimal_point_count = rhs.decimal_point_count;
        negative = rhs.negative;
        whole_units = rhs.whole_units;
        fractional_units = rhs.fractional_units;
        return *this;
    }

    bool long_decimal::operator==(const long_decimal &right) const {
        return negative == right.negative && fractional_units == right.fractional_units &&
               whole_units == right.whole_units;
    }

    long_decimal &long_decimal::operator+=(const long_decimal &rhs) {
        long_decimal ld = *this + rhs;
        negative = ld.negative;
        whole_units = ld.whole_units;
        fractional_units = ld.fractional_units;
        return *this;
    }

    long_decimal long_decimal::operator+(const long_decimal &rhs) const {

        //Flip around operands if the left is negative and the rhs is positive
        if (negative && !rhs.negative)
            return rhs + *this;

        long_decimal result;

        //bool result.negative = false;
        s_value_type borrowed = 0;
        if ((negative && rhs.negative) ||
            (rhs.negative &&
             (rhs.whole_units > whole_units ||
              (rhs.whole_units == whole_units && rhs.fractional_units > fractional_units))))
            result.negative = true;

        if (negative == rhs.negative) {
            result.fractional_units = fractional_units + rhs.fractional_units;
            borrowed = static_cast<s_value_type>(result.fractional_units / uipow(10, decimal_point_count));
            result.fractional_units %= uipow(10, decimal_point_count);
        } else {
            s_value_type temp = static_cast<s_value_type>(fractional_units + uipow(10, decimal_point_count)) -
                                static_cast<s_value_type>(rhs.fractional_units + uipow(10, decimal_point_count));
            if (temp < 0) {
                borrowed += result.negative ? 1 : -1;
                temp += static_cast<s_value_type>(uipow(10, decimal_point_count));
            }
            if (result.negative && temp < static_cast<s_value_type>(uipow(10, decimal_point_count))) {
                result.fractional_units = static_cast<value_type>(uipow(10, decimal_point_count) - temp);
                borrowed -= 1;
            } else
                result.fractional_units = static_cast<value_type>(temp) % uipow(10, decimal_point_count);
        }

        if (negative == rhs.negative) {
            result.whole_units = whole_units + rhs.whole_units + borrowed;
        } else {
            s_value_type temp;
            auto opTop = static_cast<s_value_type>(whole_units),
                    opBottom = static_cast<s_value_type>(rhs.whole_units);
            if (result.negative)
                //The larger number is negative and on the rhs
                std::swap(opTop, opBottom);

            temp = (opTop + borrowed) - opBottom;
            result.whole_units = static_cast<value_type>(temp);
        }

        return result;

    }

    long_decimal long_decimal::operator-(const long_decimal &rhs) const {
        return *this + -rhs;
    }

    long_decimal long_decimal::operator-() const {
        return {!negative, whole_units, fractional_units};
    }

    std::string long_decimal::to_string() const {
        std::ostringstream oss;
        oss << *this;
        return oss.str();
    }

    bool long_decimal::operator<(const long_decimal &rhs) const {
        if (negative < rhs.negative)
            return false;
        if (negative > rhs.negative)
            return true;
        if (whole_units < rhs.whole_units)
            return !negative;
        if (rhs.whole_units < whole_units)
            return negative;
        if (negative)
            return rhs.fractional_units < fractional_units;
        else
            return fractional_units < rhs.fractional_units;
    }

    bool long_decimal::operator>(const long_decimal &rhs) const {
        return rhs < *this;
    }

    bool long_decimal::operator<=(const long_decimal &rhs) const {
        return !(rhs < *this);
    }

    bool long_decimal::operator>=(const long_decimal &rhs) const {
        return !(*this < rhs);
    }

    std::ostream &operator<<(std::ostream &out, const long_decimal &ld) {
        out.imbue(std::locale(""));
        out << (ld.is_negative() ? "-" : "");
        out << ld.whole_value();
        out << '.'
            << std::setfill('0') << std::setw(ld.precision()) << ld.fractional_value();
        return out;
    }

    long_decimal::value_type uipow(long_decimal::value_type base, long_decimal::value_type exp) {
        //Special case looking for the default precision, avoid the linear time loop
        if (base == 10 && exp == 2)
            return 100;
        long_decimal::value_type result = 1;
        while (exp > 0) {
            if (exp & 1)
                result *= base;
            exp >>= 1;
            if (exp > 0)
                base *= base;
        }
        return result;
    }

} // End of namespace